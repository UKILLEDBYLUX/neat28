package com.example.truehealth;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

public class TrueHealthClient implements ClientModInitializer {
    /** Max distance (blocks) at which bars are drawn. */
    private static final double RANGE = 48.0;
    private static final float BAR_W = 84f;
    private static final float BAR_H = 10f;
    private static final float TEXT_SCALE = 0.75f;

    // Colors by health ratio
    private static final int COLOR_HIGH = 0xFF55CC33;   // green
    private static final int COLOR_MID = 0xFFFF9900;    // orange
    private static final int COLOR_LOW = 0xFFE02020;    // red
    private static final float MID_THRESHOLD = 0.60f;   // below this: orange
    private static final float LOW_THRESHOLD = 0.30f;   // below this: red

    @Override
    public void onInitializeClient() {
        WorldRenderEvents.AFTER_ENTITIES.register(TrueHealthClient::render);
    }

    private static void render(WorldRenderContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        ClientWorld world = client.world;
        MatrixStack matrices = context.matrixStack();
        VertexConsumerProvider consumers = context.consumers();
        if (world == null || matrices == null || consumers == null || client.options.hudHidden) return;

        Camera camera = context.camera();
        Vec3d camPos = camera.getPos();
        float delta = client.getRenderTickCounter().getTickDelta(true);

        for (Entity e : world.getEntities()) {
            if (!(e instanceof LivingEntity target)) continue;
            if (target == client.getCameraEntity()) continue;
            if (target instanceof ArmorStandEntity || target.isInvisible() || !target.isAlive()) continue;
            if (target.squaredDistanceTo(camPos) > RANGE * RANGE) continue;

            drawBar(client, matrices, consumers, camera, camPos, target, delta);
        }
    }

    private static int colorFor(float ratio) {
        if (ratio < LOW_THRESHOLD) return COLOR_LOW;
        if (ratio < MID_THRESHOLD) return COLOR_MID;
        return COLOR_HIGH;
    }

    private static void drawBar(MinecraftClient client, MatrixStack matrices,
                                VertexConsumerProvider consumers, Camera camera,
                                Vec3d camPos, LivingEntity target, float delta) {
        // Exact values. Health/absorption are synced entity data; max health is the
        // synced attribute and already includes modifiers from held/worn items.
        float health = target.getHealth();
        float maxHealth = Math.max(target.getMaxHealth(), 0.0001f);
        float absorption = target.getAbsorptionAmount();

        float ratio = MathHelper.clamp(health / maxHealth, 0f, 1f);
        float absRatio = MathHelper.clamp(absorption / maxHealth, 0f, 1f);

        Vec3d pos = target.getLerpedPos(delta).subtract(camPos);
        // Players have a nametag at height + 0.5, so go above it.
        double offset = (target instanceof PlayerEntity) ? 1.05 : 0.65;

        matrices.push();
        matrices.translate(pos.x, pos.y + target.getHeight() + offset, pos.z);
        matrices.multiply(camera.getRotation()); // face the camera
        matrices.scale(0.025f, -0.025f, 0.025f);
        Matrix4f mat = matrices.peek().getPositionMatrix();

        float x0 = -BAR_W / 2f;

        // Bar
        VertexConsumer vc = consumers.getBuffer(RenderLayer.getGui());
        quad(vc, mat, x0 - 1f, -1f, x0 + BAR_W + 1f, BAR_H + 1f, 0f, 0xC0000000);
        quad(vc, mat, x0, 0f, x0 + BAR_W, BAR_H, 0.3f, 0xFF303030);
        if (ratio > 0f) {
            quad(vc, mat, x0, 0f, x0 + BAR_W * ratio, BAR_H, 0.6f, colorFor(ratio));
        }
        if (absorption > 0f) {
            // gold strip under the bar
            quad(vc, mat, x0, BAR_H + 2f, x0 + BAR_W * absRatio, BAR_H + 4f, 0.6f, 0xFFFFD700);
        }

        // Exact numbers INSIDE the bar
        String label = String.format("%.1f", health);
        if (absorption > 0f) label += String.format(" +%.1f", absorption);
        label += String.format(" / %.1f", target.getMaxHealth());
        Text text = Text.literal(label);
        TextRenderer tr = client.textRenderer;

        matrices.push();
        matrices.translate(0f, 0f, 1.2f);            // in front of the bar
        matrices.scale(TEXT_SCALE, TEXT_SCALE, 1f);  // fit inside the bar
        Matrix4f textMat = matrices.peek().getPositionMatrix();
        float tw = tr.getWidth(text);
        float ty = (BAR_H / TEXT_SCALE - 8f) / 2f + 0.5f;
        tr.draw(text, -tw / 2f, ty, 0xFFFFFFFF, true, textMat, consumers,
                TextRenderer.TextLayerType.NORMAL, 0,
                LightmapTextureManager.MAX_LIGHT_COORDINATE);
        matrices.pop();

        matrices.pop();
    }

    /** Colored quad, emitted with both windings so it is visible whatever the culling. */
    private static void quad(VertexConsumer vc, Matrix4f m, float x1, float y1, float x2, float y2, float z, int argb) {
        vc.vertex(m, x1, y2, z).color(argb);
        vc.vertex(m, x2, y2, z).color(argb);
        vc.vertex(m, x2, y1, z).color(argb);
        vc.vertex(m, x1, y1, z).color(argb);

        vc.vertex(m, x1, y1, z).color(argb);
        vc.vertex(m, x2, y1, z).color(argb);
        vc.vertex(m, x2, y2, z).color(argb);
        vc.vertex(m, x1, y2, z).color(argb);
    }
}
